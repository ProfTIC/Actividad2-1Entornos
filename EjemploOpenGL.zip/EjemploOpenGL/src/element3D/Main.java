package element3D;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLProfile;
import com.jogamp.opengl.util.FPSAnimator;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
 
public class Main {
   public static void main(String[] args) {
        GLProfile profile = GLProfile.getDefault();            
        GLCapabilities capabilities = new GLCapabilities(profile);                    
        Figures3D canvas = new Figures3D(capabilities);
        canvas.setSize(new Dimension(600, 600));
        Panel p1 = new Panel();
        p1.setSize(600,600);
        p1.add(canvas);
        FPSAnimator animator = new FPSAnimator(canvas, 6); 
        final Frame frame = new Frame();
        frame.add(p1);
        
        Panel p2 = new Panel();
        p2.setSize(300,600);
        frame.add(p2);

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new Thread() {
                    @Override
                    public void run() {
                        System.exit(0);
                    }
                }.start();
            }
        });

        frame.setTitle("Ejemplo de uso de OpenGL con java");
        frame.setSize(p1.getWidth()+p2.getWidth(), p1.getHeight());
        frame.setVisible(true);
        
      animator.start();
    }
}