package element3D;
import com.jogamp.opengl.GL2;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.gl2.GLUT;

public class Axis2D {
    GL2 gl;
    GLU glu;
    GLUT glut;
    
    double r_text, g_text, b_text;
    double Lx, Rx, By, Uy, Nz, Fz;
    double STEP = 10;
    
    Axis2D(GL2 a, GLU b, GLUT c, double l){
        gl = a;
        glu = b;
        glut = c;
        
        Lx = -l;
        Rx =  l;
        By = -l;
        Uy =  l;
        Nz = -l;
        Fz =  l;
    }       
    
    public void dibujar3D(){
        double i, j; 
        
        double Dx = (Rx - Lx)/10;
        //double Dy = (By - Uy)/10;
        //double Dz = (Nz - Fz)/10;
        
        gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);
        
        gl.glColor3f(0.9f, 0.9f, 0.9f);
        
        //Ejes
        gl.glBegin(GL2.GL_LINES);
            gl.glVertex3d(Lx, 0, 0);
            gl.glVertex3d(Rx, 0, 0);            
            gl.glVertex3d(0, By, 0);
            gl.glVertex3d(0, Uy, 0);            
            gl.glVertex3d(0, 0, Lx);
            gl.glVertex3d(0, 0, Rx);                        
        gl.glEnd();        
        
        drawString(Lx-0.05f, 0, 0, "-X");
        drawString(Rx+0.05f, 0, 0, "+X");
        drawString(0, By-0.05f, 0, "-Y");
        drawString(0, Uy+0.05f, 0, "+Y");
        drawString(0, 0, Lx-0.05f, "-Z");
        drawString(0, 0, Rx+0.05f, "+Z");   
        
        gl.glColor3f(0.9f, 0.9f, 0.9f);
        i = Lx;
        
        while( i < Rx ){
            j = Fz;
            while( j < Fz ){
                gl.glBegin(GL2.GL_LINES);
                    gl.glVertex3d(i, By, 0);
                    gl.glVertex3d(i, Uy, 0);
                gl.glEnd();
                
            }
            i += Dx;
        }
    }     
    
    public void dibujar2D(){
        int i, j;
        
        double inix = Lx, iniy = By, iniz = 0.0f;
        
        double deltax = (Rx - Lx)/STEP;
        double deltay = (Uy - By)/STEP;    
        
        gl.glPushMatrix();
                        
        //cuadrilla
        gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_LINE);
        for(i = 0; i < STEP; ++i ){           
            gl.glColor3f(0.0f, 0.9f, 0.9f);
            iniy = By;
            gl.glBegin(GL2.GL_QUAD_STRIP);
            for(j = 0; j <= STEP; ++j ){                
                gl.glVertex3d(inix, iniy, iniz);
                gl.glVertex3d(inix+deltax, iniy, iniz);
                iniy = iniy + deltay;                
            }            
            gl.glEnd();
            
            if( i < STEP / 2 ){                
                drawString(inix, 0.01f, 0, "" + (int) (Math.round(inix*100))/100.0f);
                drawString(0.01f, inix, 0, "" + (int) (Math.round(inix*100))/100.0f);
            }            
            if( i == STEP / 2 ){
                drawString(inix, 0.01f, 0, "" + (int) (Math.round(inix*100))/100.0f);
            }
            if( i > STEP / 2 ) {
                drawString(inix, 0.01f, 0, "" + (int) (Math.round(inix*100))/100.0f);
                drawString(0, inix, 0, "" + (int) (Math.round(inix*100))/100.0f);                
            }
            
            inix = inix + deltax;
        }        
        
        gl.glPolygonMode(GL2.GL_FRONT_AND_BACK, GL2.GL_FILL);
        
        gl.glColor3f(0.5f, 0.5f, 0.5f);
        
        //Ejes
        gl.glBegin(GL2.GL_LINES);
            gl.glVertex3d(Lx, 0, 0);
            gl.glVertex3d(Rx, 0, 0);            
            gl.glVertex3d(0, By, 0);
            gl.glVertex3d(0, Uy, 0);            
        gl.glEnd();       
        
        gl.glPopMatrix();
    }
    
    public void drawString(double x, double y, double z, String string)
    {
        char c;
        int i;
        gl.glColor3d(r_text, g_text, b_text);
        
        gl.glRasterPos3d(x, y, z);
        for (i = 0; i < string.length(); ++i ){
            c = string.charAt(i);
            
            gl.glColor3f(0.0f, 0.0f, 0.0f);
            glut.glutBitmapCharacter(GLUT.BITMAP_TIMES_ROMAN_10, c);
        }
    }    
    
}
