package element3D;
import com.jogamp.opengl.GL2;

public class Graphics_Scene {
    public static final int XY = 0;
    public static final int XZ = 1;
    public static final int YZ = 2;
   // private static final int X = 0;
  //  private static final int Y = 1;
   // private static final int Z = 2;
   // private static final int SIZE = 10;
    
    public static void drawCircle(GL2 gl, float R, int numv) {
        double angulo = 0.0f, deltaangulo = 2*Math.PI/2;
        double Dx, Dy;
        
        gl.glBegin(GL2.GL_POLYGON);
        for (int i = 0; i < numv; ++i) {
            Dx = (float) (1 * Math.cos(angulo * Math.PI / 180));
            Dy = (float) (1 * Math.sin(angulo * Math.PI / 180));            
            
            gl.glVertex3d(Dx, Dy, 0);
            angulo = angulo + deltaangulo;
        }
        gl.glEnd();
    }    
        
    public static void drawCube(GL2 gl, double L){
        double Lx = -L/2, By = -L/2, Nz = -L/2;
        double Rx =  L/2, Uy =  L/2, Fz =  L/2;
                                
        gl.glBegin(GL2.GL_QUADS);    
            gl.glColor3f(1,0,0);
            gl.glVertex3d(Lx, By, Nz);
            gl.glVertex3d(Lx, Uy, Nz);
            gl.glVertex3d(Rx, Uy, Nz);
            gl.glVertex3d(Rx, By, Nz);
            
            gl.glColor3f(0.5f,0,0);
            gl.glVertex3d(Lx, By, Fz);
            gl.glVertex3d(Lx, Uy, Fz);
            gl.glVertex3d(Rx, Uy, Fz);
            gl.glVertex3d(Rx, By, Fz);
            
            gl.glColor3f(0,1,0);
            gl.glVertex3d(Rx, By, Nz);
            gl.glVertex3d(Rx, By, Fz);
            gl.glVertex3d(Lx, By, Fz);
            gl.glVertex3d(Lx, By, Nz);
            
            gl.glColor3f(0,0.0f,1);
            gl.glVertex3d(Rx,  Uy, Nz);
            gl.glVertex3d(Rx,  Uy, Fz);
            gl.glVertex3d(Lx,  Uy, Fz);
            gl.glVertex3d(Lx,  Uy, Nz);
                        
            gl.glColor3f(0,0,1);
            gl.glVertex3d(Lx, Uy, Nz);
            gl.glVertex3d(Lx, Uy, Fz);
            gl.glVertex3d(Lx, By, Fz);
            gl.glVertex3d(Lx, By, Nz);
            
            gl.glColor3f(1,0.5f,0.25f);
            gl.glVertex3d(Rx, Uy, Nz);
            gl.glVertex3d(Rx, Uy, Fz);
            gl.glVertex3d(Rx, By, Fz);
            gl.glVertex3d(Rx, By, Nz);
        gl.glEnd();
        gl.glColor3f(0,1f,0.5f);
    }
    
    public static  void drawSphere(GL2 gl, float R, int numv){
        float DX=0, DY=0, DZ=0;
        float angulo = 0, deltaangulo = 360.0f/numv;
        float theta; //, deltatheta;
        float PX, PY, PZ;
        float [][][]vertices = new float[numv][numv][3];
        float [][]poligono = new float[3][3];
    //    float []normal = new float[3];
        
                
        for(int i = 0; i <= numv/2+1; ++i ){
            DX = (float) (R * Math.sin(angulo * Math.PI/180));
            DY = (float) (R * Math.cos(angulo * Math.PI/180));
            DZ = 0f;                                                
            gl.glPushMatrix();
            gl.glTranslatef(0,DY,0);
            theta = 0;
            gl.glBegin(GL2.GL_POLYGON);            
            
            for(int j = 0; j < numv; ++j ){
                PX = (float) (DX * Math.sin(theta * Math.PI / 180));
                PY = 0f;
                PZ = (float) (DX * Math.cos(theta * Math.PI / 180));   
                
                vertices[i][j][0] = PX;
                vertices[i][j][1] = DY + PY;
                vertices[i][j][2] = PZ;
                
                //gl.glVertex3f(PX, PY, PZ);       
                theta = theta + deltaangulo;
            }
            gl.glEnd();
            gl.glPopMatrix();
            angulo = angulo + deltaangulo;
        }
        
        for(int i = 0; i <= numv/2+1; ++i ){
            for(int j = 0; j < numv; ++j ){
                int nj = (j+1) % numv;
                gl.glBegin(GL2.GL_QUAD_STRIP);
                
                   poligono[2][0] = vertices[i][j][0]; poligono[1][0] = vertices[i][nj][0]; poligono[0][0] = vertices[i+1][j][0];
                   poligono[2][1] = vertices[i][j][1]; poligono[1][1] = vertices[i][nj][1]; poligono[0][1] = vertices[i+1][j][1];
                   poligono[2][2] = vertices[i][j][2]; poligono[1][2] = vertices[i][nj][2]; poligono[0][2] = vertices[i+1][j][2];        
                
                    gl.glVertex3f(vertices[i][j][0], vertices[i][j][1], vertices[i][j][2]);
                    gl.glVertex3f(vertices[i][nj][0], vertices[i][nj][1], vertices[i][nj][2]);
                    gl.glVertex3f(vertices[i+1][j][0], vertices[i+1][j][1], vertices[i+1][j][2]);
                    gl.glVertex3f(vertices[i+1][nj][0], vertices[i+1][nj][1], vertices[i+1][nj][2]);                                        
                gl.glEnd();
            }
                    
        }        
    }
}
