package element3D;
import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLEventListener;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.gl2.GLUT;


public class Figures3D extends GLCanvas implements GLEventListener {
     public static double LIMITE = 2;
    double angulo = 0;
    GLU glu;
    GLUT glut;    
    
    double Lx =  -0.1;
    double Rx =   0.1;    
    double By =  -0.1;
    double Uy =   0.1;
    double Nz =   0.1;
    double Fz = 100.0; 
    double incremento =0.1;
    double sizeX=2;
    double sizex=-1;
    double sizeY=-2;
    
     float limiteSuperior =  2.0f;
    float limiteInferior = -2.0f;
    float contador = -1.0f;
    boolean arriba = true;

    
    
    Figures3D(GLCapabilities cap){
        super(cap);
        this.addGLEventListener(this);
    }

    @Override
    public void init(GLAutoDrawable glad) {
        GL2 gl = glad.getGL().getGL2();
        
        gl.glClearColor(0.75f,0.75f,0.75f,1.0f);

        gl.glMatrixMode(gl.GL_PROJECTION);

        gl.glLoadIdentity();

        gl.glFrustum (Lx, Rx, By, Uy, Nz, Fz);
        //gl.glOrtho (Lx, Rx, By, Uy, Nz, Fz);
        
        gl.glMatrixMode(gl.GL_MODELVIEW);  
        gl.glEnable(GL2.GL_DEPTH_TEST);
        
        glu = new GLU();
        
        glu.gluLookAt(LIMITE,LIMITE,LIMITE,0,0,0,0,1,0);
        
        glut = new GLUT();
    }

    @Override
    public void dispose(GLAutoDrawable glad) {
    }

    @Override
    public void display(GLAutoDrawable glad) {
        GL2 gl = glad.getGL().getGL2();
        gl.glClear(gl.GL_COLOR_BUFFER_BIT | gl.GL_DEPTH_BUFFER_BIT);
        Axis2D c = new Axis2D(gl, glu, glut, LIMITE);
        c.dibujar3D();      
       //gl.glTranslated(0,0,1);
     // gl.glScaled(1,0,0);
        /* gl.glPushMatrix();
             
             gl.glTranslated(sizeX,0,0);
           sizeX+=incremento;
                 
           if(sizeX >=-2){
             incremento *=0.1;
            
             }
             Graficos.drawCube(gl, 0.5f);   
        gl.glPopMatrix();
        
      gl.glPushMatrix();
           gl.glTranslated(sizex,0,0);
           sizex+=incremento;
           if(sizex >=2 ){
             incremento *=.1;
            
             }
                  
             Graficos.drawCube(gl, 0.5f);   
        gl.glPopMatrix();*/
        
                  

        //DIBUJAMOS LA CUADRILLA QUE NOS SERVIRA COMO GUIA
        gl.glPushMatrix();     
           
            c.dibujar3D();
        gl.glPopMatrix();
        //DIBUJAMOS LOS CUBOS QUE SE TRASLADAN SOBRE SUS EJES Y REGRESAN
        //DIBUJAMOS EL CUBO ANIMADO QUE SUBE DESDE -"Y" HASTA "Y"
        gl.glPushMatrix();
            if(contador < limiteSuperior && arriba == true)
            {
                contador += 0.25;
                if(contador == limiteSuperior)
                {
                    arriba = false;
                }
            }else
                if(contador > limiteInferior && arriba == false)
                {
                    contador -= 0.25;
                    if(contador == limiteInferior)
                    {
                        arriba = true;
                    }
                }
            gl.glTranslated(0, contador, 0);
            Graphics_Scene.drawCube(gl, 0.5f);

        gl.glPopMatrix();


        //DIBUJAMOS EL CUBO ANIMADO QUE SE TRASLADA DESDE -"Z" HASTA "Z"
        gl.glPushMatrix();
            if(contador < limiteSuperior && arriba == true)
            {
                contador += 0.25;
                if(contador == limiteSuperior)
                {
                    arriba = false;
                }
            }else
                if(contador > limiteInferior && arriba == false)
                {
                    contador -= 0.25;
                    if(contador == limiteInferior)
                    {
                        arriba = true;
                    }
                }
            gl.glTranslated(0, 0, contador);
        Graphics_Scene.drawSphere(gl,0.7f,20);
        gl.glPopMatrix();
        //DIBUJAMOS EL CUBO ANIMADO QUE SE TRASLADA DESDE "Z" HASTA -"Z"
        gl.glPushMatrix();
            if(contador < limiteSuperior && arriba == true)
            {
                contador += 0.25;
                if(contador == limiteSuperior)
                {
                    arriba = false;
                }
            }else
                if(contador > limiteInferior && arriba == false)
                {
                    contador -= 0.25;
                    if(contador == limiteInferior)
                    {
                        arriba = true;
                    }
                }
            gl.glTranslated(0, 0, -contador);
           Graphics_Scene.drawCube(gl, 0.5f);
        gl.glPopMatrix();
    }

    @Override
    public void reshape(GLAutoDrawable glad, int i, int i1, int i2, int i3) {
    }
    
}
